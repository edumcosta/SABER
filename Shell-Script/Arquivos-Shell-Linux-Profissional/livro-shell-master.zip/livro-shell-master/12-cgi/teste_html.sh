#!/bin/bash
# teste_html.sh

echo Content-type: text/html
echo

echo "<h1>Testando... 1, 2, 3</h1>"
