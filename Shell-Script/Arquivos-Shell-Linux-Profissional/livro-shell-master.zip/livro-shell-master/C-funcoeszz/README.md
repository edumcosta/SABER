# Funções ZZ versão 8.3

Para sua comodidade aqui está uma cópia da versão 8.3 das Funções ZZ.
Para baixar uma versão atualizada do programa, visite seu site em
http://funcoeszz.net.

Para saber qual dos dois arquivos irá funcionar corretamente com as
configurações de seu sistema, chame-os com a opção -v e use aquele
cujos acentos aparecerem corretamente.

    $ ./funcoeszz-latin1 -v
    Fun??es ZZ v8.3
    $ ./funcoeszz-utf8 -v
    Funções ZZ v8.3
    $

Neste caso, o sistema utilizado é UTF-8.
